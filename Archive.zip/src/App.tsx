import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AdminAuthProvider } from "@/context/AdminAuthContext.tsx";
import Index from "./pages/Index.tsx";
import AdminLogin from "./pages/AdminLogin.tsx";
import AdminCreate from "./pages/AdminCreate.tsx";
import AdminDashboard from "./pages/AdminDashboard.tsx";
import AdminPortal from "./pages/AdminPortal.tsx";
import ParticipantSession from "./pages/ParticipantSession.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AdminAuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin/portal" element={<AdminPortal />} />
            <Route path="/admin/create" element={<AdminCreate />} />
            <Route path="/admin/:code" element={<AdminDashboard />} />
            <Route path="/session/:code" element={<ParticipantSession />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AdminAuthProvider>
  </QueryClientProvider>
);

export default App;
